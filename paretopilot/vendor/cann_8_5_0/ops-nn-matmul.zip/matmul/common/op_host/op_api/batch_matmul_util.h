/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef OP_API_SRC_LEVEL2_BATCH_MATMUL_UTIL_H_
#define OP_API_SRC_LEVEL2_BATCH_MATMUL_UTIL_H_

#include "aclnn/aclnn_base.h"
#include "opdev/common_types.h"
#include "opdev/platform.h"

#ifdef __cplusplus
extern "C" {
#endif

namespace Ops {
namespace NN {
const aclTensor *ExecBmmOpWithBiasV2(const aclTensor *self, const aclTensor *mat2, const aclTensor *bias,
    const aclTensor *out, int8_t cubeMathType, aclOpExecutor *executor, bool isBaddbmm = false);

const aclTensor *ExecBatchMatmulOpWithBiasAndAttrsV2(const aclTensor *self, const aclTensor *mat2, const aclTensor *bias,
    const aclTensor *out, bool adjX1, bool adjX2,
    int8_t cubeMathType, aclOpExecutor *executor, bool isTransposeMat2Contiguous = false, bool isBaddbmm = false);

const aclTensor *ExecBmmOpV2(const aclTensor *self, const aclTensor *mat2, const aclTensor *out, int8_t cubeMathType,
    aclOpExecutor *executor, bool isBaddbmm = false);

}  // namespace Ops
}  // namespace NN

#ifdef __cplusplus
}
#endif

#endif  // OP_API_SRC_LEVEL2_BATCH_MATMUL_UTIL_H_